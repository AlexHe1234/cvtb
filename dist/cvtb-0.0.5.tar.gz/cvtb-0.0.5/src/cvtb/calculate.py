import numpy as np


# lift image points into camera space 3d points
def lift(k: np.ndarray, img: np.ndarray, dpt: np.ndarray, msk: np.ndarray) -> np.ndarray:
    pass
    

if __name__ == '__main__':
    k = np.array([[517.,   0., 320.],
                  [  0., 517., 240.],
                  [  0.,   0.,   1.]])
    img = None

